package utils;

public interface StringResource {
    String CANCEL = "cancel";
    String AVAILABLE = "Available";
    String REGISTER="regester";
    String SUCCESS_REGISTERED = "User Registered Successfully";
    String SUCCESS_CREATED = "Driver Registered Successfully";
    String SUCCESS_BOOKED = "Driver Booked Successfully";
    String CANCEL_MESSAGE = "Driver cancelled Successfully";

    String DELETE_MESSAGE = "Customer deleted Successfully";

    String CANNOT_DELETE_MESSAGE = "Customer cannot deleted";

    String UPDATE_STATUS = "Driver Status Updated Successfully";
    String BOOKED = "Booked";
    String REACHED = "Reached";

    String HI = "/hi/**";
    String GET_LIST = "/getList/**";

    String BOOKING_DETAILS = "/insertBookingDetails/**";
    String UPDATE_STATUS_URL = "/updateAmbulanceStatus/**";

    String ROLE = "admin";

    String URL_CANCEL_DRIVER = "/cancelAmbulance/**";
    String REGESTER_URL = "/createCustomer/**";

    String USER = "ammms";
    String PASSWORD = "password";
    String CREATE_AMBULANCE="/createAmbulance/**";

    String DELETE_CUSTOMER="/deleteCustomer/**";
    String GET_AMBULANCE_LIST="/getAmbulanceList";
    String GET_AMBULANCE_BY_NUMBER="/getAmbulanceByNumber";
    String GET_AMBULANCE_BY_CODE="/getAmbulanceByCode";
    String NEW_AMBULANCE="/createAmbulance";
    String UPDATE_AMBULANCE="/updateAmbulanceStatus";
    String CANCEL_AMBULANCE="/cancelAmbulance";
    String CREATE_CUSTOMER="/createCustomer";
    String DELETE_CUSTOMER_BY_ID="/deleteCustomer";

    String INSERT_BOOKING="/insertBookingDetails";

    String SEARCH_CUSTOMER_CONTACTNO="/searchByCusContactNo";

    String GET_CUSTOMERS="/getCustomers";

    String GET_BY_ID="/getAmbulancebyId";
}
