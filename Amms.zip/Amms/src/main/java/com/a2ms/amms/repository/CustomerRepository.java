package com.a2ms.amms.repository;

import com.a2ms.amms.entitiy.Ambulance;
import com.a2ms.amms.entitiy.Customer;
import jakarta.transaction.Transactional;

import java.util.*;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends CrudRepository<Customer,Long> {

    @Transactional
    @Modifying()
    @Query(value = "update amms_customer cust set cust.CUSTOMER_STATUS = ?2 where cust.CUSTOMER_ID= ?1",nativeQuery=true)
    public int updateCustomerStatus(Long customerId,String customerStatus);

    @Transactional
    @Modifying()
    @Query(value = "delete from amms_customer cust where cust.CUSTOMER_ID= ?1 and cust.CUSTOMER_STATUS = ?2",nativeQuery=true)
    public void deleteByCustomerIdAndCustomerStatus(Long customerId,String customerStatus);

    public Customer findByCustomerContactNo(String customerContactNo);

}
