package com.a2ms.amms.controller;

import com.a2ms.amms.entitiy.Ambulance;
import com.a2ms.amms.entitiy.BookingDetails;
import com.a2ms.amms.entitiy.Customer;
import com.a2ms.amms.entitiy.Response;
import com.a2ms.amms.interfaces.AmmsServiceInterface;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import utils.StringResource;

@RestController
public class AmmsRestController {

    @Autowired
    public AmmsServiceInterface ammsServiceInterface;

    //Basic API
    @PutMapping("/hi")
    public String sayHi(@RequestBody String name) {
        return "hi all ammr" + StringResource.USER;
    }

    //Registeration of Customer
    @PostMapping(StringResource.CREATE_CUSTOMER)
    public Response save(@RequestBody Customer customer) {
        System.out.println(customer);
        Customer customers = ammsServiceInterface.regesterUser(customer);
        return new Response(customers.getCustomerId(), StringResource.SUCCESS_REGISTERED);
    }

    //Registeration of Ambulance
    @PostMapping(StringResource.NEW_AMBULANCE)
    public Response save(@RequestBody Ambulance customer) {
        System.out.println(customer);
        Ambulance ambulance = ammsServiceInterface.createAmbulance(customer);
        return new Response(ambulance.getAmbulanceId(), StringResource.SUCCESS_CREATED);
    }

    //Transaction of API which inserts the Status of Ambulance and Customer
    @PostMapping(StringResource.INSERT_BOOKING)
    public Response save(@RequestBody BookingDetails customer) {
        System.out.println(customer);
        BookingDetails bookingDetails = ammsServiceInterface.insertBookingDetails(customer);
        return new Response(bookingDetails.getTransactionId(), StringResource.SUCCESS_BOOKED);
    }

    //API for Cancel Driver
    @PutMapping(StringResource.CANCEL_AMBULANCE)
    public Response cancelDriver(@RequestParam(value = "customerId") Long customerId, @RequestBody BookingDetails customer) {
        System.out.println(customer);
        ammsServiceInterface.cancelDriver(customerId, customer);

        return new Response(customerId, StringResource.CANCEL_MESSAGE);

    }
    //Updating the status of Ambulance

    @PutMapping(StringResource.UPDATE_AMBULANCE)
    public Response updateStatus(@RequestParam(value = "ambulanceId") Long ambulanceId, @RequestBody BookingDetails customer) {
        System.out.println(customer);
        ammsServiceInterface.updateStatus(ambulanceId, customer);
        return new Response(ambulanceId, StringResource.UPDATE_STATUS);
    }

    @GetMapping(StringResource.GET_AMBULANCE_LIST)
    public List<Ambulance> listAmbulance() {
        return ammsServiceInterface.getAvailableAmbulanceList();
    }

    //Deleting a registered customer
    @DeleteMapping(StringResource.DELETE_CUSTOMER_BY_ID)
    public Response deleteCustomer(@RequestParam(value = "customerId") Long customerId) {
        System.out.println(customerId);
        String message = ammsServiceInterface.deleteByCustomerIdAndCustomerStatus(customerId);
        return new Response(customerId, message);
    }
    //API to get the list of Ambulance available

    @GetMapping(StringResource.GET_AMBULANCE_BY_NUMBER)
    public List<Ambulance> getByContactNo(@RequestParam(value = "contactNo") String contactNo) {
        List<Ambulance> customer = ammsServiceInterface.getByContactNumber(contactNo);
        return customer;
    }

    //API to get the list of Customers
    @GetMapping(StringResource.GET_AMBULANCE_BY_CODE)
    public Ambulance getByAmbulanceCode(@RequestParam(value = "code") String code) {
        return ammsServiceInterface.getByCode(code);
    }

    //API to get the Details of Ambulance by getting ID
    @GetMapping(StringResource.SEARCH_CUSTOMER_CONTACTNO)
    public Customer searchByCusContactNo(@RequestParam(value = "contactNo") String code) {
        return ammsServiceInterface.searchByCusContactNo(code);
    }

    //API to get the Details of Customer by getting the input as Contact No
    @GetMapping(StringResource.GET_BY_ID)
    public Optional<Ambulance> getAmbulancebyId(@RequestParam(value = "ambulanceId") Long code) {
        return ammsServiceInterface.getAmbulancebyId(code);
    }
    //API to get the list of Customers

    @GetMapping("/getCustomers")
    public List<Customer> getListOfCustomers() {
        return ammsServiceInterface.getListOfCustomers();
    }
}
