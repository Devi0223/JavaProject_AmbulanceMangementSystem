package com.a2ms.amms.security;

import java.util.Arrays;

import javax.sql.DataSource;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;


import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import utils.StringResource;


@Configuration
@EnableWebSecurity(debug = true)

public class AmmsSecurity  {

    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails user = User.withDefaultPasswordEncoder()
                .username("amms")
                .password("amms@123")
                .roles(StringResource.ROLE)
                .build();
        return new InMemoryUserDetailsManager(user);
    }
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http.authorizeHttpRequests().requestMatchers(StringResource.GET_LIST).permitAll()
                .requestMatchers(StringResource.HI).permitAll()
                .requestMatchers(StringResource.BOOKING_DETAILS).authenticated()
                .requestMatchers(StringResource.UPDATE_STATUS_URL).authenticated()
                .requestMatchers(StringResource.URL_CANCEL_DRIVER).authenticated()
                .requestMatchers(StringResource.CREATE_AMBULANCE).authenticated()
                .requestMatchers(StringResource.DELETE_CUSTOMER).authenticated()
                .requestMatchers(StringResource.GET_CUSTOMERS+"/**").authenticated()
                .requestMatchers(StringResource.GET_AMBULANCE_LIST+"/**").permitAll()
                .requestMatchers(StringResource.GET_AMBULANCE_BY_NUMBER+"/**").authenticated()
                .requestMatchers(StringResource.GET_AMBULANCE_BY_CODE+"/**").authenticated()
                .requestMatchers(StringResource.SEARCH_CUSTOMER_CONTACTNO+"/**").authenticated()
                .requestMatchers(StringResource.GET_BY_ID+"/**").authenticated()

                .requestMatchers(StringResource.DELETE_CUSTOMER).authenticated()
                 .requestMatchers("/v2/api-docs",
                         "/v3/api-docs/**",
                "/swagger-resources/configuration/ui",
                "/swagger-resources/configuration/security",
                "/webjars/**",
                "/swagger-ui.html","/swagger-ui/**").permitAll()
                .requestMatchers(StringResource.REGESTER_URL).authenticated()
                .and().httpBasic();
        http.csrf().disable(); // 403forbidden error
        http.cors().disable();
        return http.build();
    }



//    @Bean
//    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
//
//        AuthenticationManagerBuilder authenticationManagerBuilder = http
//                .getSharedObject(AuthenticationManagerBuilder.class);
//        authenticationManagerBuilder.authenticationProvider(travellerAuthProvider);
//        return authenticationManagerBuilder.build();
//    }

}
