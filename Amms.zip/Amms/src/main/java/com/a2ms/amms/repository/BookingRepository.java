package com.a2ms.amms.repository;

import com.a2ms.amms.entitiy.BookingDetails;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends CrudRepository<BookingDetails,Long> {
}
