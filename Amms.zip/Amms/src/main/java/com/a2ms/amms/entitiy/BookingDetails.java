package com.a2ms.amms.entitiy;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;
@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "amms_bookingDetails")
public class BookingDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long transactionId;

    @Column(nullable = false)
    private String status;

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Timestamp transactionRegDateTime;

    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name="custId", referencedColumnName="customerId")
    private Customer customer;

    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name="ambuId", referencedColumnName="ambulanceId")
    private Ambulance ambulance;
}
