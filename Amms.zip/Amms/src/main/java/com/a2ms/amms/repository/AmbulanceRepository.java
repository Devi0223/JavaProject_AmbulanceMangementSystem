package com.a2ms.amms.repository;

import com.a2ms.amms.entitiy.Ambulance;
import com.a2ms.amms.entitiy.Customer;
import jakarta.transaction.Transactional;


import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface AmbulanceRepository extends CrudRepository<Ambulance,Long> {

    public List<Ambulance> findByAmbulanceStatusIgnoreCase(String ambulanceStatus);

    public Ambulance findByAmbulanceCodeAndAmbulanceStatusIgnoreCase(String ambulanceContactNo,String ambulanceStatus);
    @Transactional
    @Modifying
    @Query(value = "update amms_ambulance amb set amb.Ambulance_STATUS = ?2 where amb.ambulance_ID= ?1",nativeQuery = true)
    public int updateAmbulanceStatus(Long ambulanceId, String ambulanceStatus);

    public List<Ambulance> findByAmbulanceContactNoContaining(String customerContactNo);
}
