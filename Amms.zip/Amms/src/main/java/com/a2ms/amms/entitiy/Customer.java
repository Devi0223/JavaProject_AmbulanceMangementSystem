package com.a2ms.amms.entitiy;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;
import java.util.Date;
@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "amms_customer")
public class Customer  {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long customerId;
    @Column(nullable = false)
    private String customerName;
    @Column(nullable = false,unique = true)
    private String customerContactNo;
    @Column(nullable = false)
    private String customerAddress;
    @Column(nullable = false)
    private String customerCity;
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private String customerRegDateTime;
    @Column(nullable = false)
    private String customerStatus;


}
