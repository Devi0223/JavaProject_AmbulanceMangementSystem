package com.a2ms.amms.entitiy;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Response {

    private Long id;
    private String message;


}
