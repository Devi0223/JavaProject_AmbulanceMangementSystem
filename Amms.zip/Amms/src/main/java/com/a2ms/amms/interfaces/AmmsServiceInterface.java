package com.a2ms.amms.interfaces;

import com.a2ms.amms.entitiy.Ambulance;
import com.a2ms.amms.entitiy.BookingDetails;
import com.a2ms.amms.entitiy.Customer;
import java.util.*;
public interface AmmsServiceInterface {

    public  Customer regesterUser(Customer customer);

    public Ambulance createAmbulance(Ambulance ambulance);

    public BookingDetails insertBookingDetails(BookingDetails bookingDetails);

    public List<Ambulance> getAvailableAmbulanceList();

    public  void updateStatus(Long id,BookingDetails bookingDetails);

    public void cancelDriver(Long id ,BookingDetails bookingDetails);


    public String deleteByCustomerIdAndCustomerStatus(Long id);

    public Ambulance getByCode(String code);

    public List<Ambulance> getByContactNumber(String number);
    public List<Customer> getListOfCustomers();
    
    public Customer searchByCusContactNo(String customerContactNo);
    
    public Optional<Ambulance> getAmbulancebyId(Long tId);
    
}
