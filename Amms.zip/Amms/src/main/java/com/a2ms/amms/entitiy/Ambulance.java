package com.a2ms.amms.entitiy;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "amms_ambulance")
public class Ambulance {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ambulanceId;
    @Column(nullable = false,unique = true)
    private String ambulanceCode;
    @Column(nullable = false)
    private String ambulanceDrive;
    @Column(nullable = false)
    private String ambulanceContactNo;
    @Column(nullable = false)
    private String ambulanceStatus;
}
