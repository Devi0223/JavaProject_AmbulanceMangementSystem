package com.a2ms.amms.service;

import com.a2ms.amms.entitiy.Ambulance;
import com.a2ms.amms.entitiy.BookingDetails;
import com.a2ms.amms.entitiy.Customer;
import com.a2ms.amms.interfaces.AmmsServiceInterface;
import com.a2ms.amms.repository.AmbulanceRepository;
import com.a2ms.amms.repository.BookingRepository;
import com.a2ms.amms.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import utils.StringResource;

import java.util.List;
import java.util.Optional;

@Service
public class AmmsServiceImp  implements AmmsServiceInterface {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private AmbulanceRepository ambulanceRepository;

    @Override
    public Customer regesterUser(Customer customer) {
       return customerRepository.save(customer);

    }

    @Override
    public Ambulance createAmbulance(Ambulance ambulance) {
        return ambulanceRepository.save(ambulance);
    }

    @Override
    public BookingDetails insertBookingDetails(BookingDetails bookingDetails) {
        Customer updateCust=customerRepository.findById(bookingDetails.getCustomer().getCustomerId()).get();
        System.out.println(updateCust);
        int id=customerRepository.updateCustomerStatus(bookingDetails.getCustomer().getCustomerId(),StringResource.BOOKED);
        int id1=ambulanceRepository.updateAmbulanceStatus(bookingDetails.getAmbulance().getAmbulanceId(),StringResource.BOOKED);
        return bookingRepository.save(bookingDetails);
    }

    @Override
    public List<Ambulance> getAvailableAmbulanceList() {
        return ambulanceRepository.findByAmbulanceStatusIgnoreCase(StringResource.AVAILABLE);
    }

    @Override
    public void updateStatus(Long amblulanceId,BookingDetails bookingDetails) {
        bookingRepository.save(bookingDetails);
        int s=customerRepository.updateCustomerStatus(bookingDetails.getCustomer().getCustomerId(),StringResource.REACHED);
        int id=ambulanceRepository.updateAmbulanceStatus(amblulanceId,StringResource.AVAILABLE);


    }
		@Override
	public Optional<Ambulance> getAmbulancebyId(Long tId) {
		return ambulanceRepository.findById(tId);
	}
		@Override
	public Customer searchByCusContactNo(String customerContactNo) {
		return customerRepository.findByCustomerContactNo(customerContactNo);
	}

    @Override
    public void cancelDriver(Long customerId,BookingDetails bookingDetails) {
        bookingRepository.save(bookingDetails);
        int s=customerRepository.updateCustomerStatus(customerId, StringResource.CANCEL);
        int id=ambulanceRepository.updateAmbulanceStatus(bookingDetails.getAmbulance().getAmbulanceId(),StringResource.AVAILABLE);
    }

    @Override
    public String deleteByCustomerIdAndCustomerStatus(Long id) {
        Customer customer=customerRepository.findById(id).get();
        System.out.println(customer);
        if(customer.getCustomerStatus().equals(StringResource.REGISTER)){
         customerRepository.deleteByCustomerIdAndCustomerStatus(id,StringResource.REGISTER);
            return StringResource.DELETE_MESSAGE;
        }else {
            return StringResource.CANNOT_DELETE_MESSAGE;
        }
    }

    @Override
    public Ambulance getByCode(String code) {
        return ambulanceRepository.findByAmbulanceCodeAndAmbulanceStatusIgnoreCase(code,StringResource.AVAILABLE);
    }

    @Override
    public List<Ambulance> getByContactNumber(String number) {


        return (List<Ambulance>) ambulanceRepository.findByAmbulanceContactNoContaining(number);


    }
    @Override

    public List<Customer> getListOfCustomers() {

        return (List<Customer>) customerRepository.findAll();

    }
}
