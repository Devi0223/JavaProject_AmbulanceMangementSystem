package com.a2ms.amms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmmsApplication.class, args);
	}

}
